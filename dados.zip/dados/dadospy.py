with open('dados.csv', 'r', encoding='utf-8') as f:
    linha = f.readlines()
    contador = len(linha)


def isDelimiter(i, linha):
    if i < len(linha) - 1:
        if linha[i] + linha[i + 1] == ",":
            return False
        if linha[i] == "," and linha[i + 1] != " ":
            return True
    else:
        return True


def quebrar_linha_em_coluna(linhas):
    tamanho = len(linhas)

    dados = 0
    entre_aspas = False
    quebra_em_colunas = []

    for i in range(0, tamanho):
        if linhas[i] == '"':
            entre_aspas = not entre_aspas
        elif isDelimiter(i, linhas) and not entre_aspas:
            quebra_em_colunas.append(linhas[dados:i + 0])
            dados = i + 1
    return quebra_em_colunas


with open('saidadadoshtml.html', 'w', encoding='utf-8') as f:
    f.write(
        '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Artigos selecionados</title></head><body><h1>Artigos '
        'selecionados</h1>\n')
    f.write('<table border ="1px">\n')
    f.write('<thead><tr><th>DOI</th><th>Title</th><th>Authors</th><th>Journal</th><th>Year</th></tr></thead>\n')
    f.write('<tbody>\n')

    year_anterior = ""

    for linhas in linha:
        valores = quebrar_linha_em_coluna(linhas)
        DOI = valores[0]
        title = valores[3]
        authors = valores[5]
        journal = valores[-2]
        year = valores[-1]

        if DOI != "DOI":
            if year == "":
                year = year_anterior
            year_anterior = year

            f.write(
                f'<tr><td>{DOI}</td><td>{title}</td><td>{authors}</td><td>{journal}</td><td>{year}</td></tr>\n')

    f.write('</tbody></table>\n')
    f.write('</body></html>\n')
    f.write(f'<p>Quantidade de registros: {contador}</p>\n')